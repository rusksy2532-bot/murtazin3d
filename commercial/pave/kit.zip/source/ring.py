# -*- coding: utf-8 -*-
"""Seven-stone half-hoop study. All Rhino geometry is in millimetres."""
import Rhino
from Rhino import Geometry as G
from Rhino.Geometry import Point3d as P, Vector3d as V
from Rhino.DocObjects import ObjectAttributes, Layer
from System.Drawing import Color
import os, math, json, struct, traceback

HERE=os.path.dirname(os.path.abspath(__file__))
OUT=os.path.join(HERE,'export')
if not os.path.isdir(OUT): os.makedirs(OUT)
TOL=.0001
BORE=8.5
OUTER=10.08
GIRDLE=9.93
PITCH=1.40/GIRDLE

def revolve(curve):
    brep=G.Brep.CreateFromRevSurface(G.RevSurface.Create(curve,G.Line(P.Origin,P(0,0,1))),True,True)
    assert brep and brep.IsSolid and brep.IsValid
    if brep.SolidOrientation==G.BrepSolidOrientation.Inward:brep.Flip()
    return brep

def turn(profile):
    return revolve(G.PolylineCurve([P(r,0,z) for r,z in profile]))

def place(shape,angle,r,side=0):
    dest=G.Plane(P(r*math.sin(angle),r*math.cos(angle),side),V(math.cos(angle),-math.sin(angle),0),V(0,0,-1))
    copy=shape.DuplicateBrep()
    copy.Transform(G.Transform.PlaneToPlane(G.Plane.WorldXY,dest))
    return copy

def one(result):
    assert result and len(result)==1 and result[0].IsValid and result[0].IsSolid
    return result[0]

def make_stone():
    profiles=[(.018,-.43,0),(.6,-.020,0),(.6,.015,0),(.39,.18,math.pi/16)]
    mesh=G.Mesh()
    n=16
    for r,z,offset in profiles:
        for j in range(n):
            a=2*math.pi*j/n+offset
            mesh.Vertices.Add(r*math.cos(a),r*math.sin(a),z)
    for i in range(3):
        for j in range(n):
            a=i*n+j;b=i*n+(j+1)%n
            mesh.Faces.AddFace(a,b,b+n);mesh.Faces.AddFace(a,b+n,a+n)
    for j in range(1,n-1):
        mesh.Faces.AddFace(0,j+1,j);mesh.Faces.AddFace(3*n,3*n+j,3*n+j+1)
    mesh.Normals.ComputeNormals()
    return G.Brep.CreateFromMesh(mesh,True)

def export_mesh(shape,filename):
    settings=G.MeshingParameters.QualityRenderMesh
    settings.Tolerance=.002
    settings.MaximumEdgeLength=.25
    settings.MinimumEdgeLength=.003
    mesh=G.Mesh()
    for frag in G.Mesh.CreateFromBrep(shape,settings):mesh.Append(frag)
    mesh.Faces.ConvertQuadsToTriangles()
    mesh.Vertices.CombineIdentical(True,True);mesh.Faces.CullDegenerateFaces();mesh.Compact()
    mesh.FaceNormals.ComputeFaceNormals()
    with open(filename,'wb') as stream:
        stream.write(b'RR Design - pave ring'.ljust(80,b' '));stream.write(struct.pack('<I',mesh.Faces.Count))
        for i,f in enumerate(mesh.Faces):
            n=mesh.FaceNormals[i];vs=[v for v in (mesh.Vertices[f.A],mesh.Vertices[f.B],mesh.Vertices[f.C])]
            values=[n.X,n.Y,n.Z]+[v for p in vs for v in [p.X,p.Y,p.Z]]
            stream.write(struct.pack('<12fH',*(values+[0])))
    return mesh.IsClosed

try:
    corners=[(BORE,-1.10),(OUTER,-1.10),(OUTER,1.10),(BORE,1.10),(BORE,-1.10)]
    profile=G.Curve.CreateFilletCornersCurve(G.PolylineCurve([P(r,0,z) for r,z in corners]),.20,TOL,.001)
    ring=revolve(profile)
    # Shallow open relief on the bore. The two finger-contact lands retain size 17.
    groove=[(8.10,-.64),(8.53,-.64),(8.78,-.38),(8.78,.38),(8.53,.64),(8.10,.64),(8.10,-.64)]
    groove_profile=G.Curve.CreateFilletCornersCurve(G.PolylineCurve([P(r,0,z) for r,z in groove]),.11,TOL,.001)
    ring=one(G.Brep.CreateBooleanDifference(ring,revolve(groove_profile),TOL))
    cutter=turn([(.35,-2),(.35,-.25),(.42,-.16),(.6001,-.0201),(.606,.02),(.625,.65)])
    stone=make_stone()
    bead=turn([(.265,.01),(.265,.31),(.244,.35),(.218,.36)])
    stones=[]
    for k in range(7):
        a=(k-3)*PITCH
        ring=one(G.Brep.CreateBooleanDifference(ring,place(cutter,a,GIRDLE),TOL))
        stones.append(place(stone,a,GIRDLE))
    for k in range(8):
        a=(k-3.5)*PITCH
        for side in [-.52,.52]:
            ring=one(G.Brep.CreateBooleanUnion([ring,place(bead,a,GIRDLE,side)],TOL))
    model=Rhino.FileIO.File3dm()
    model.Settings.ModelUnitSystem=Rhino.UnitSystem.Millimeters;model.Settings.ModelAbsoluteTolerance=TOL
    for name,c in [('RR_Cast_Band',Color.Goldenrod),('RR_Stones_Reference',Color.LightCyan)]:
        layer=Layer();layer.Name=name;layer.Color=c;model.Layers.Add(layer)
    for i,shape in enumerate([ring]+stones):
        attr=ObjectAttributes();attr.LayerIndex=int(i>0);attr.Name='Metal' if i==0 else 'Pave%02d'%i
        model.Objects.AddBrep(shape,attr)
        export_mesh(shape,os.path.join(OUT,attr.Name+'.stl'))
    filename=os.path.join(OUT,'Pave.3dm')
    assert model.Write(filename,8)
    reopened=Rhino.FileIO.File3dm.Read(filename)
    assert len(list(reopened.Objects))==8 and all(o.Geometry.IsValid and o.Geometry.IsSolid for o in reopened.Objects)
    data=dict(engine=str(Rhino.RhinoApp.Version),volume=G.VolumeMassProperties.Compute(ring).Volume,archive=reopened.ArchiveVersion,innerDiameter=2*BORE,pitchMm=GIRDLE*PITCH,prongs=16,stemDiameter=.53,crownAboveGirdle=.345)
except Exception:
    data=dict(error=traceback.format_exc())
with open(os.path.join(HERE,'result.json'),'w') as f:json.dump(data,f)
