# -*- coding: utf-8 -*-
"""Light solitaire B. RunPythonScript in desktop Rhino; units are millimetres."""
import math
import os
import json
import traceback
import Rhino
from Rhino import Geometry as G
from System.Drawing import Color

folder = os.path.dirname(os.path.abspath(__file__))
P = G.Point3d
V = G.Vector3d
tolerance = 0.001
bore = 17.0
width = 2.18
radial_wall = 1.36
channel_width = 0.68
channel_depth = 0.55
axis_z = G.Line(P.Origin, P(0, 0, 1))
axis_y = G.Line(P.Origin, P(0, 1, 0))

def solid(brep, label):
    if brep is None or not brep.IsValid or not brep.IsSolid:
        raise RuntimeError('Invalid or open solid: ' + label)
    if brep.SolidOrientation == G.BrepSolidOrientation.Inward:
        brep.Flip()
    return brep

def turned(section, axis, angle=360.0, corner=0.0):
    pts = [P(r, 0, w) if axis == axis_z else P(r, w, 0) for r, w in section]
    outline = G.PolylineCurve(pts+[pts[0]])
    if corner:
        outline = G.Curve.CreateFilletCornersCurve(outline, corner, tolerance, .001)
    surface = G.RevSurface.Create(outline, axis, 0, math.radians(angle))
    body = G.Brep.CreateFromRevSurface(surface, False, False)
    body.Faces.SplitKinkyFaces(.01, True)
    if not body.IsSolid:
        body = body.CapPlanarHoles(tolerance)
    return solid(body, 'revolution')

def difference(stock, tool, label):
    pieces = G.Brep.CreateBooleanDifference(stock, tool, tolerance)
    if not pieces or len(pieces) != 1:
        raise RuntimeError('Boolean cut: '+label)
    return solid(pieces[0], label)

def mesh_of(body):
    params = G.MeshingParameters.QualityRenderMesh
    params.Tolerance = 0.003
    params.RefineGrid = True
    params.RefineAngle = math.radians(8)
    params.MaximumEdgeLength = 0.65
    result = G.Mesh()
    for piece in G.Mesh.CreateFromBrep(body, params):
        result.Append(piece)
    result.Faces.ConvertQuadsToTriangles()
    result.Vertices.CombineIdentical(True, True)
    result.Weld(math.pi)
    result.Normals.ComputeNormals()
    result.Compact()
    return result

def upper_leg(angle):
    loops = []
    for radius, height, section in [(1.49,10.18,.39),(2.05,10.88,.40),
         (2.73,11.80,.39),(3.26,12.57,.375),(3.44,12.96,.35),(3.44,13.73,.35)]:
        point=P(radius*math.cos(angle),height,radius*math.sin(angle))
        loops.append(G.Circle(G.Plane(point,V.YAxis),section).ToNurbsCurve())
    shell=G.Brep.CreateFromLoft(loops,P.Unset,P.Unset,G.LoftType.Straight,False)[0]
    return solid(shell.CapPlanarHoles(tolerance), 'prong')

def build():
    band=turned([(bore/2,-width/2),(bore/2+radial_wall,-width/2),
                 (bore/2+radial_wall,width/2),(bore/2,width/2)],axis_z,corner=.135)
    # Six open milled/castable recesses with full-width transverse bridges.
    for start in [112,157,202,247,292,337]:
        cutter=turned([(bore/2-.2,-channel_width/2),(bore/2+channel_depth,-channel_width/2),
                       (bore/2+channel_depth,channel_width/2),(bore/2-.2,channel_width/2)],axis_z,37,.055)
        cutter.Rotate(math.radians(start),V.ZAxis,P.Origin)
        band=difference(band,cutter,'relief '+str(start))
    # Widen only the shoulders around the light window. The two sloped flanks
    # are trimmed by an ellipsoid, keeping the underside of the band light.
    pad_stock=turned([(bore/2+.012,-1.75),(bore/2+radial_wall-.012,-1.75),
                      (bore/2+radial_wall-.012,1.75),(bore/2+.012,1.75)],axis_z,corner=.12)
    ellipsoid=G.Sphere(P.Origin,1).ToBrep()
    assert ellipsoid.Transform(G.Transform.Scale(G.Plane.WorldXY,4.7,2.5,1.87))
    ellipsoid.Translate(0,9.22,0)
    parts=G.Brep.CreateBooleanIntersection(pad_stock,ellipsoid,tolerance)
    if not parts or len(parts)!=1:raise RuntimeError('Shoulder trim')
    merged=G.Brep.CreateBooleanUnion([band,parts[0]],tolerance)
    if not merged or len(merged)!=1:raise RuntimeError('Shoulder union')
    band=solid(merged[0],'shoulder reinforcement')
    lower=turned([(.92,9.70),(1.36,9.70),(1.83,9.92),(1.83,10.48),(1.79,10.54),(.92,10.54)],axis_y)
    upper=turned([(2.26,11.77),(3.0,11.77),(3.50,12.12),(3.50,12.64),
                  (3.46,12.72),(2.26,12.72)],axis_y)
    legs=[upper_leg(math.radians(a)) for a in (45,135,225,315)]
    union=G.Brep.CreateBooleanUnion([band,lower,upper]+legs,tolerance)
    if not union or len(union)!=1: raise RuntimeError('Assembly union failed')
    stock=solid(union[0],'assembly')
    # Place the round seat around the actual stone envelope. Leave 5 microns
    # radially at nominal Z to absorb mesh tessellation; test 0.020 mm overtravel.
    envelope=turned([(.005,10.48),(.040,10.49),(1.806,11.88),(3.006,12.94),
                     (3.006,18),(.005,18)],axis_y)
    stock=difference(stock,envelope,'stone seat')
    through=G.Cylinder(G.Circle(G.Plane(P(0,7,0),V.YAxis),.92),3.7).ToBrep(True,True)
    stock=difference(stock,through,'light window')
    return stock

try:
    body=build()
    mesh=mesh_of(body)
    model=Rhino.FileIO.File3dm()
    model.Settings.ModelUnitSystem=Rhino.UnitSystem.Millimeters
    model.Settings.ModelAbsoluteTolerance=tolerance
    metal_layer=Rhino.DocObjects.Layer();metal_layer.Name='01 Metal - editable Brep'
    metal_layer.Color=Color.Silver
    model.AllLayers.Add(metal_layer)
    attr=Rhino.DocObjects.ObjectAttributes();attr.LayerIndex=0;attr.Name='Metal'
    model.Objects.AddBrep(body,attr)
    src=json.load(open(os.path.join(folder,'stone.json')))
    stone=G.Mesh()
    for pt in src['vertices']:stone.Vertices.Add(*pt)
    for face in src['faces']:stone.Faces.AddFace(*face)
    stone.Normals.ComputeNormals();stone.Compact()
    layer=Rhino.DocObjects.Layer();layer.Name='02 Stone - control mesh';layer.Color=Color.Aquamarine
    model.AllLayers.Add(layer)
    att=Rhino.DocObjects.ObjectAttributes();att.LayerIndex=1;att.Name='Stone'
    model.Objects.AddMesh(stone,att)
    filename=os.path.join(folder,'Light-Solitaire.3dm')
    assert model.Write(filename,8)
    reopened=Rhino.FileIO.File3dm.Read(filename)
    test=[o.Geometry for o in reopened.Objects if o.Attributes.Name=='Metal'][0]
    assert isinstance(test,G.Brep) and test.IsSolid and test.IsValid
    with open(os.path.join(folder,'metal.json'),'w') as f:
        json.dump(dict(vertices=[[float(p.X),float(p.Y),float(p.Z)] for p in mesh.Vertices],
                       faces=[[int(t.A),int(t.B),int(t.C)] for t in mesh.Faces]),f)
    report=dict(engine=str(Rhino.RhinoApp.Version),archive=reopened.ArchiveVersion,
                brepFaces=test.Faces.Count,brepVolume=G.VolumeMassProperties.Compute(test).Volume,
                validSolid=True,reliefPockets=6,minimumNominalFloor=radial_wall-channel_depth,
                minimumNominalSide=(width-channel_width)/2)
except Exception:
    report=dict(error=traceback.format_exc())
with open(os.path.join(folder,'rhino-result.json'),'w') as file:json.dump(report,file)
