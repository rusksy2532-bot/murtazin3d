"""Unify coincident vertices across Rhino panel seams before issuing final STL."""
from pathlib import Path
import sys,json
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here.parents[2]/'work/portrait-r3/libs'))
import trimesh as tm,numpy as np
from scipy.spatial import cKDTree
result={}
for name in ['Stud','Nut','Stone']:
    path=here/'export'/(name+'.stl')
    raw=tm.load_mesh(path,process=False);m=raw.copy();m.merge_vertices(digits_vertex=7)
    d=cKDTree(m.vertices).query(raw.vertices)[0].max()
    assert d<=.00000015
    result[name]=float(d)
    m.export(path)
(here/'seam-weld.json').write_text(json.dumps(result),'utf8')
