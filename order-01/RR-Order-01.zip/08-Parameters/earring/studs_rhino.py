# -*- coding: utf-8 -*-
"""Run in Rhino. Z+ points away from the ear, units are mm."""
import os,math,datetime,json,traceback,struct
import Rhino
from Rhino import Geometry as G
from Rhino.Geometry import Point3d as P,Vector3d as V
from Rhino.DocObjects import ObjectAttributes,Layer
from System.Drawing import Color
here=os.path.dirname(os.path.abspath(__file__))
out=os.path.join(here,'export')
TOL=.0001

def turned(profile):
    c=G.PolylineCurve([P(r,0,z) for r,z in profile])
    return solid(G.Brep.CreateFromRevSurface(G.RevSurface.Create(c,G.Line(P.Origin,P(0,0,1))),True,True))

def solid(b):
    assert b and b.IsValid and b.IsSolid
    if b.SolidOrientation==G.BrepSolidOrientation.Inward:b.Flip()
    return b

def union(parts,name):
    bs=G.Brep.CreateBooleanUnion(parts,TOL)
    assert bs and len(bs)==1,(name,len(bs) if bs else 'empty')
    return solid(bs[0])

def strut(a,b,r):
    a,b=P(*a),P(*b)
    axis=b-a
    pl=G.Plane(a,axis)
    return solid(G.Cylinder(G.Circle(pl,r),axis.Length).ToBrep(True,True))

def shifted(b,x,y,z):
    c=b.DuplicateBrep();c.Translate(x,y,z)
    return c

def stone():
    levels=[(.035,1.,0),(2.25,2.68,0),(2.25,2.74,0),(1.33,3.53,math.pi/32)]
    n=32;m=G.Mesh()
    for r,z,p in levels:
        for j in range(n):
            a=2*math.pi*j/n+p
            m.Vertices.Add(r*math.cos(a),r*math.sin(a),z)
    for i in range(len(levels)-1):
        for j in range(n):
            a=i*n+j;b=i*n+(j+1)%n
            m.Faces.AddFace(a,b,b+n);m.Faces.AddFace(a,b+n,a+n)
    for j in range(1,n-1):
        m.Faces.AddFace(0,j+1,j);m.Faces.AddFace(3*n,3*n+j,3*n+j+1)
    m.Normals.ComputeNormals()
    return solid(G.Brep.CreateFromMesh(m,True))

def meshout(shape,name):
    s=G.MeshingParameters.QualityRenderMesh
    s.Tolerance=.0008;s.MaximumEdgeLength=.18;s.MinimumEdgeLength=.002
    mesh=G.Mesh()
    for piece in G.Mesh.CreateFromBrep(shape,s):mesh.Append(piece)
    mesh.Faces.ConvertQuadsToTriangles();mesh.Vertices.CombineIdentical(True,True)
    mesh.Faces.CullDegenerateFaces();mesh.Compact();mesh.FaceNormals.ComputeFaceNormals()
    with open(os.path.join(out,name+'.stl'),'wb') as f:
        f.write(b'R&R Design - study 01 mm'.ljust(80,b' '));f.write(struct.pack('<I',mesh.Faces.Count))
        for i,face in enumerate(mesh.Faces):
            v=[mesh.Vertices[k] for k in [face.A,face.B,face.C]]
            n=mesh.FaceNormals[i]
            f.write(struct.pack('<12fH',*([n.X,n.Y,n.Z]+[x for p in v for x in (p.X,p.Y,p.Z)]+[0])))

stamp=lambda:datetime.datetime.now().isoformat()
log={'start':stamp()}
try:
    # Solid inner face sits against the lobe. Four inclined round stays leave lateral windows.
    base=turned([(1.77,0),(1.85,.08),(1.85,.57),(1.73,.74)])
    # Round support section, tangent to the actual pavilion. A tapered ledge
    # with two flat ends left thin chords at its upper and lower arrises.
    slope=(2.25-.035)/(2.68-1.0)
    gallery_z=2.20;section_radius=.50
    gallery_r=.035+slope*(gallery_z-1)+section_radius*math.sqrt(1+slope*slope)+.002
    seat=solid(G.Torus(G.Plane(P(0,0,gallery_z),V.ZAxis),gallery_r,section_radius).ToBrep())
    legs=[];tips=[]
    for k in range(4):
        a=math.pi/4+k*math.pi/2;c=math.cos(a);s=math.sin(a)
        legs.append(strut((1.45*c,1.45*s,.46),(2.46*c,2.46*s,2.27),.47))
        finger=turned([(.38,2.29),(.38,3.29),(.37,3.34),(.36,3.37)])
        tips.append(shifted(finger,2.66*c,2.66*s,0))
    head=union([base,seat]+legs+tips,'basket')
    pin=turned([(.39,-9.8),(.50,-9.67),(.50,-.23),(.61,-.10),(.67,.07)])
    stud=union([head,pin],'post')
    # Body of nut with through pilot. Smoothed axial tapers make the lobes easy to grip.
    flange=turned([(.30,0),(1.84,0),(2.10,.21),(2.10,.62),(1.80,.88),(1.72,1.20),(1.80,1.70),(2.04,2.15),(2.04,2.46),(1.82,2.67),(.30,2.67),(.30,0)])
    lobes=[]
    for sign in [-1,1]:
        ear=turned([(.59,.31),(.81,.55),(.85,.97),(.85,1.70),(.76,2.13),(.55,2.34)])
        lobes.append(shifted(ear,sign*1.72,0,0))
    nut=union([flange]+lobes,'wings')
    gem=stone()
    model=Rhino.FileIO.File3dm()
    model.Settings.ModelUnitSystem=Rhino.UnitSystem.Millimeters;model.Settings.ModelAbsoluteTolerance=TOL
    for title,color in [('RR_Cast_Stud',Color.Goldenrod),('RR_Cast_Nut',Color.Khaki),('RR_Stone_Reference',Color.LightCyan)]:
        l=Layer();l.Name=title;l.Color=color;model.Layers.Add(l)
    for i,(name,b) in enumerate([('Stud',stud),('Nut',nut),('Stone',gem)]):
        attr=ObjectAttributes();attr.LayerIndex=i;attr.Name=name
        model.Objects.AddBrep(shifted(b,0,0,-9.45) if name=='Nut' else b,attr)
        meshout(b,name)
    fil=os.path.join(out,'Studs.3dm')
    assert model.Write(fil,8)
    reopen=Rhino.FileIO.File3dm.Read(fil)
    assert len(list(reopen.Objects))==3 and all(o.Geometry.IsValid and o.Geometry.IsSolid for o in reopen.Objects)
    log.update(engine=str(Rhino.RhinoApp.Version),archive=reopen.ArchiveVersion,volumes={name:G.VolumeMassProperties.Compute(b).Volume for name,b in [('Stud',stud),('Nut',nut),('Stone',gem)]})
except Exception:
    log['error']=traceback.format_exc()
log['end']=stamp()
with open(os.path.join(here,'cad.json'),'w') as f:json.dump(log,f)
