"""Build one millimetre-based layered Rhino assembly per size from final STLs."""
from model import *
sys.path.insert(0,str(root/'work/duet-casting/author-libs'))
import rhino3dm as rh
import json
for size in (16,17,18):
    name='Ring'+str(size)
    qa=json.loads((folder/(name+'-qa.json')).read_text())
    model=rh.File3dm()
    model.Settings.ModelUnitSystem=rh.UnitSystem.Millimeters
    model.Settings.ModelAbsoluteTolerance=.001
    for label in ['01 Metal','02 Centre','03 Left shoulder','04 Right shoulder']:
        layer=rh.Layer();layer.Name=label;model.Layers.Add(layer)
    for label,fname,layer in [(name,name+'.stl',0)]+[(s['id'],s['filename'],1 if s['id']=='Center' else 2 if s['id'][4]=='L' else 3) for s in qa['stones']]:
        obj=tm.load_mesh(folder/fname)
        geo=rh.Mesh()
        for p in obj.vertices:geo.Vertices.Add(*p)
        for tri in obj.faces:geo.Faces.AddFace(*map(int,tri))
        geo.Normals.ComputeNormals();geo.Compact()
        attr=rh.ObjectAttributes();attr.LayerIndex=layer;attr.Name=label
        attr.SetUserString('STL millimetres',fname)
        model.Objects.AddMesh(geo,attr)
    path=folder/(name+'.3dm')
    assert model.Write(str(path),8)
    reread=rh.File3dm.Read(str(path))
    assert len(reread.Objects)==14 and len(reread.Layers)==4
    assert reread.Settings.ModelUnitSystem==rh.UnitSystem.Millimeters and reread.ArchiveVersion==80
    print(path.name,14,'meshes',4,'layers',flush=True)
