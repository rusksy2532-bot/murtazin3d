"""Section-based measurements on the delivered STL. All axes in millimetres."""
from model import *
import json
from datetime import datetime
def run(size):
    r=size/2
    mesh=tm.load_mesh(folder/('Ring%d.stl'%size))
    m=manifold(mesh)
    def hits(p,q):return np.asarray([h.position for h in m.ray_cast(p,q)])
    def radial(a):return np.array([math.cos(a),math.sin(a),0.])
    up=np.array([0.,0.,1.]);eye=np.array([0.,1.,0.])
    culet=r+1.75;girdle=culet+2.195
    diameters=[];gallery=[]
    # Z just below the top of the angled bearing, measured between the
    # opposite empty inner surfaces across the nominal insert axis.
    height=culet+1.855
    for a in np.arange(36)*math.pi/36:
        p=up*height;d=radial(a)
        forward=hits(p,p+d*4)[0]
        backward=hits(p,p-d*4)[0]
        diameters.append(float(np.linalg.norm(forward-backward)))
    # Shoot across the conical sleeve perpendicular to its inner profile.
    slope=(2.205-1.12)/(1.86-.85)
    for a in np.arange(72)*math.pi/36:
        n=radial(a);direction=(n-slope*up)/math.sqrt(1+slope*slope)
        for low in np.linspace(.90,1.81,15):
            p=up*(culet+low)+n*(1.12+slope*(low-.85))
            ray=hits(p-.12*direction,p+2.4*direction)
            if len(ray)>=2:gallery.append(float(np.linalg.norm(ray[1]-ray[0])))
    shafts=[]
    for a in np.deg2rad([45,135,225,315]):
        p=2.97*radial(a)+up*(girdle+.35)
        ds=[]
        for angle in np.arange(12)*math.pi/12:
            d=radial(angle)
            hs=hits(p-.65*d,p+.65*d)
            ds.append(float(np.linalg.norm(hs[1]-hs[0])))
        shafts.append([min(ds),max(ds)])
    # Extremal height of the free annular gallery at +Y, away from the arms.
    # Count original float32 vertices on its axial section, grouping nearest
    # similarly elevated triangles from the collar, exclude ring and stone.
    v=mesh.vertices
    mask=(np.abs(v[:,0])<.00003)&(v[:,1]>.99)&(v[:,1]<2.90)&(v[:,2]>culet+.10)
    local=v[mask,2]
    tip=float(v[:,2].max())
    qfile=folder/('Ring%d-qa.json'%size)
    q=json.loads(qfile.read_text())
    q['centralGauges']={'seatPlaneZmm':height,'innerSeatDiameterRangeMm':[min(diameters),max(diameters)],
      'galleryNormalRays':len(gallery),'galleryMinNormalWallMm':min(gallery),
      'gallerySectionZRangeMm':[float(min(local)),float(max(local))], 'galleryAxialSpanMm':float(np.ptp(local)),
      'shaftGaugeZmm':girdle+.35,'prongDiametersMm':shafts,'girdleTopZmm':girdle,
      'prongTipZmm':tip,'prongReserveMm':tip-girdle,'stoneCrownAboveGirdleMm':culet+3.05-girdle}
    openings=[]
    french=[]
    for side in (-1,1):
        a=math.radians(tilt*side)
        n=np.array([math.sin(a),0,math.cos(a)]);t=np.array([n[2],0,-n[0]])
        for i in range(6):
            s=side*(i-2.5)*pitch
            center=t*s+n*math.sqrt(r*r-s*s)
            nr=center/r;tr=np.array([nr[2],0,-nr[0]])
            # Actual lower bore on an orthogonal section 0.03 mm into metal;
            # surface on the inside of the ring is cylindrical, hence curved.
            inside=center+.03*nr
            out_diam=[]
            for angle in np.arange(12)*math.pi/12:
                d=eye*math.cos(angle)+tr*math.sin(angle)
                hit1=hits(inside,inside+.7*d)[0];hit2=hits(inside,inside-.7*d)[0]
                out_diam.append(float(np.linalg.norm(hit1-hit2)))
            coord=t*s+n*(r+distance_to_flat)
            top_diam=[]
            for angle in np.arange(12)*math.pi/12:
                d=eye*math.cos(angle)+t*math.sin(angle)
                p=coord-n*.0002
                hit1=hits(p,p+.65*d)[0];hit2=hits(p,p-.65*d)[0]
                top_diam.append(float(np.linalg.norm(hit1-hit2)))
            openings.append({'side':side,'index':i+1,'lowerAxis':nr.tolist(),'lowerCentreXYZ':center.tolist(),
                'exitOrthogonalDiameterRangeMm':[min(out_diam),max(out_diam)],
                'deckDiameterRangeMm':[min(top_diam),max(top_diam)]})
            for hand in (-1,1):
                for flank in (-1,1):
                    chords=[]
                    for depth in (.001,.030,.075,.14,.22,.32):
                        p=coord-n*depth
                        for azimuth in np.deg2rad(np.arange(52,81,1.)):
                            d=hand*t*math.cos(azimuth)+flank*eye*math.sin(azimuth)
                            h=hits(p,p+d*1.45)
                            if len(h)<2:continue
                            x=np.dot(h[1]-coord,t)*hand;y=np.dot(h[1]-coord,eye)*flank
                            # Accept the actual cut surfaces, excluding the regular
                            # outside rail at 1.025 and the flat deck chamfer.
                            if .21<x<.75 and .835<y<.992:
                                chords.append(float(np.linalg.norm(h[1]-h[0])))
                    assert chords,(size,i,hand,flank)
                    vsite=coord+hand*.45*t+flank*1.018*eye
                    vx=hits(vsite+n*.20,vsite-n*.80)
                    vdepth=float(np.dot(vsite-vx[0],n))
                    french.append({'side':side,'stone':i+1,'hand':hand,'flank':flank,
                      'samples':len(chords),'minLigamentFromHoleMm':min(chords),'outerNotchDepthMm':vdepth})
    q['paveGauges']=openings
    q['frenchGauges']=french
    q.pop('wallSurvey',None)
    q['completedGaugeTime']=datetime.now().astimezone().isoformat(timespec='seconds')
    qfile.write_text(json.dumps(q,indent=2),'utf8')
    print(size,q['centralGauges'],openings[0],flush=True)
if __name__=='__main__':
    for z in map(int,sys.argv[1:] or [16,17,18]):run(z)
