from model import *
import json
from datetime import datetime

for size in (17,16,18):
    r=size/2; stock=shank(r)
    mesh=tm.load_mesh(folder/('Ring%d.stl'%size))
    metal=manifold(mesh)
    cuts=[];access=[]
    for side in (-1,1):
        for i in range(6):
            s=side*(i-2.5)*pitch
            seat=tilted(drill(s,r),side,r)^stock
            for hand in (-1,1):
                for flank in (-1,1):
                    hollow=tilted(french_notch(s,hand,flank),side,r)^stock
                    cuts.append({'side':side,'stone':i+1,'hand':hand,'flank':flank,
                                 'trueToolSurfaceGapWithinShankMm':seat.min_gap(hollow,1.)})
    for angle in [101,106,112,118,123,146,151,157,163,168,192,197,203,209,214,237,242,248,254,259]:
        theta=math.radians(angle)
        n=np.array([math.sin(theta),0,math.cos(theta)])
        # The complete straight, flat-ended gauge fills its whole approach
        # path from the middle of the bore. Four microns to nominal floor.
        cyl=M.cylinder(r+.576,.15,.15,48).rotate((0,angle,0))
        access.append({'azimuthDeg':angle,'overlapToFloorMinus004Mm3':abs((cyl^metal).volume()),
                       'overtravel0020Mm3':abs((cyl.translate(n*.020)^metal).volume())})
    assert max(t['overlapToFloorMinus004Mm3'] for t in access)<1.e-7 and min(t['overtravel0020Mm3'] for t in access)>.0005
    assert min(t['trueToolSurfaceGapWithinShankMm'] for t in cuts)>.45
    out={'size':size,'stockCutGaps':cuts,'gaugeDiameterMm':.30,'gaugeFloorClearanceMm':.004,
         'toolAccess':access,'time':datetime.now().astimezone().isoformat(timespec='seconds')}
    (folder/('Ring%d-access.json'%size)).write_text(json.dumps(out,indent=2),'utf8')
    print(size,min(t['trueToolSurfaceGapWithinShankMm'] for t in cuts),min(t['overtravel0020Mm3'] for t in access),flush=True)
