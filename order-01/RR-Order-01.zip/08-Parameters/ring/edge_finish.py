"""Collapse connected sub-micron STL edges in millimetres after float32 export."""
import numpy as np
import trimesh

MIN_EDGE = .001


def topology(vertices, faces, grid=None):
    points = vertices if grid is None else np.rint(vertices / grid)
    _, labels = np.unique(points, axis=0, return_inverse=True)
    triangles = labels.reshape(-1)[faces]
    edges = np.concatenate([triangles[:, [0, 1]], triangles[:, [1, 2]], triangles[:, [2, 0]]])
    keys = np.sort(edges, axis=1)
    _, ids, counts = np.unique(keys, axis=0, return_inverse=True, return_counts=True)
    winding = np.bincount(ids.reshape(-1), weights=np.sign(edges[:, 1]-edges[:, 0]))
    return dict(collapsed=int(np.sum(keys[:, 0]==keys[:, 1])), open=int(np.sum(counts==1)),
                nonManifold=int(np.sum(counts>2)), inconsistent=int(np.sum(winding!=0)))


def lengths(vertices, faces):
    edges = np.unique(np.sort(np.concatenate([faces[:, [0,1]], faces[:, [1,2]], faces[:, [2,0]]]), axis=1),axis=0)
    return edges, np.linalg.norm(vertices[edges[:,0]]-vertices[edges[:,1]],axis=1)


def finish(mesh):
    vertices, labels = np.unique(mesh.vertices.astype('float32'), axis=0, return_inverse=True)
    vertices = vertices.astype('float64')
    faces = labels.reshape(-1)[mesh.faces]
    for attempt in range(12):
        edges, distance = lengths(vertices, faces)
        snapped = np.rint(vertices / MIN_EDGE)
        same_cell = np.all(snapped[edges[:,0]] == snapped[edges[:,1]], axis=1)
        short = edges[(distance < MIN_EDGE) | same_cell]
        if not len(short):
            break
        parent = np.arange(len(vertices))
        def root(i):
            while parent[i] != i:
                i = parent[i]
            return i
        for a,b in short:
            parent[root(b)] = root(a)
        _, inverse = np.unique([root(i) for i in range(len(vertices))], return_inverse=True)
        # Keep the vertex supported by the largest incident faces. An average
        # can pull the edge of a V cut off its plane and leave a folded sliver.
        tri = vertices[faces]
        areas = np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)
        support = np.bincount(faces.ravel(),weights=np.repeat(areas,3),minlength=len(vertices))
        order = np.lexsort((-support,inverse))
        vertices = vertices[order[np.r_[True,np.diff(inverse[order])!=0]]]
        faces = inverse[faces]
        faces = faces[(faces[:,0]!=faces[:,1]) & (faces[:,0]!=faces[:,2]) & (faces[:,1]!=faces[:,2])]
    else:
        raise ValueError('Edge collapse did not converge')
    out = trimesh.Trimesh(vertices, faces, process=False)
    for grid in [None, .0001, .001]:
        status = topology(vertices, faces, grid)
        if any(status.values()):
            raise ValueError((grid, status))
    if not out.is_volume:
        raise ValueError('Invalid solid after edge collapse')
    return out
