"""Cross-sections normal to the axis of each central support at every level."""
from model import *
import json
def run(size):
    m=manifold(tm.load_mesh(folder/('Ring%d.stl'%size)));r=size/2
    datum=r+1.75
    levels=np.array([[.77,r+1.10],[1.25,r+1.74],[2.17,r+2.71],
                     [2.93,datum+1.73],[2.97,datum+2.12],[2.97,datum+2.935]])
    record=[]
    for angle in np.deg2rad([45,135,225,315]):
        radial=np.array([np.cos(angle),np.sin(angle),0]);cross=np.array([-radial[1],radial[0],0]);up=np.array([0,0,1])
        for k,(lo,hi) in enumerate(zip(levels,levels[1:])):
            axis=hi-lo;axis=axis/np.linalg.norm(axis)
            transverse=radial*axis[1]-up*axis[0]
            for t in np.linspace(.015,.985,25):
                rr,z=lo+(hi-lo)*t;p=radial*rr+up*z
                for a in np.deg2rad(np.arange(0,181,5)):
                    d=transverse*np.cos(a)+cross*np.sin(a)
                    f=m.ray_cast(p,p+d*6);b=m.ray_cast(p,p-d*6)
                    if not(f and b):continue
                    width=np.linalg.norm(np.array(f[0].position)-b[0].position)
                    record.append((width,p.tolist(),k,t))
    # Outside the deliberately pierced pavé zone, survey the full ring
    # circumference, including shoulders downstream of both rows. Each ray
    # follows the radius through one y-lane, starting inside the finger bore.
    band=[]
    for theta in np.arange(-180,180,2):
        if 10.0<=abs(theta)<=72.0:continue
        rad=math.radians(theta);n=np.array([math.sin(rad),0,math.cos(rad)])
        for y in (.0,.17,-.17,.235,-.235,.34,-.34,.60,-.60,.86,-.86,.95,-.95):
            p=n*(r-.08)+[0,y,0]
            h=m.ray_cast(p,p+3.45*n)
            if len(h)<2:continue
            band.append((float(np.linalg.norm(np.asarray(h[1].position)-h[0].position)),int(theta),y))
    q={'size':size,'throughCentreSections':len(record),'minimum':min(record),
       'unpiercedBandSections':len(band),'minimumUnpiercedBandSection':min(band)}
    print(size,q,flush=True)
    (folder/('Ring%d-braces.json'%size)).write_text(json.dumps(q,indent=2),'utf8')
if __name__=='__main__':
    for size in map(int,sys.argv[1:] or [17,16,18]):run(size)
