"""Probe structural shoulders just beyond the two French-pavé decks."""
from model import *
import json
for size in [16,17,18]:
    r=size/2
    ring=manifold(tm.load_mesh(folder/('Ring%d.stl'%size)))
    rows=[]
    for side in (-1,1):
        a=math.radians(side*tilt);deck=np.array([math.sin(a),0,math.cos(a)])
        tangent=np.array([deck[2],0,-deck[0]])
        for t in np.r_[-np.arange(4.67,6.11,.06),np.arange(4.67,6.11,.06)]:
            p=(r+distance_to_flat)*deck+t*tangent
            normal=p/np.linalg.norm(p)
            for y in (0,.25,-.25,.55,-.55,.83,-.83,.95,-.95):
                for vec in [normal,deck]:
                    # Start in the free bore so this is the continuous band
                    # section; a ray from above could meet a separate lug first.
                    h=ring.ray_cast(p+[0,y,0]-5.5*vec,p+[0,y,0]+1.8*vec)
                    if len(h)>=2:
                        width=float(np.linalg.norm(np.asarray(h[0].position)-h[1].position))
                        rows.append((width,h[0].position))
    assert min(rows)[0]>.70,(size,min(rows))
    file=folder/('Ring%d-braces.json'%size)
    q=json.loads(file.read_text());q['fourDeckTransitionRayCount']=len(rows)
    q['minFourDeckTransitionMm']=min(rows)[0];q['minTransitionXYZ']=list(min(rows)[1])
    file.write_text(json.dumps(q,indent=2),'utf8')
    print(size,len(rows),min(rows)[0],flush=True)
