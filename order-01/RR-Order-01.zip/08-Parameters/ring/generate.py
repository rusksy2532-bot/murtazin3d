"""From the extracted ring source folder: python generate.py 16 17 18 [--output DIR]."""
import argparse
from pathlib import Path
from model import series,vecmesh,casting_mesh

def main():
    parser=argparse.ArgumentParser(description='Rebuild order 01 metal and stone-reference STL in millimetres.')
    parser.add_argument('sizes',nargs='+',type=int,choices=[16,17,18])
    parser.add_argument('--output',type=Path,default=Path('generated'))
    args=parser.parse_args()
    for size in args.sizes:
        target=args.output/str(size)
        target.mkdir(parents=True,exist_ok=True)
        metal,stones=series(size)
        for name,body in [(f'Ring{size}',metal),*stones.items()]:
            mesh = casting_mesh(body) if name.startswith('Ring') else vecmesh(body)
            mesh.export(target/(name+'.stl'))

if __name__=='__main__':main()
