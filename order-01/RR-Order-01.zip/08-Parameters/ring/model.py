"""Order 01. Parametric master, mm, XZ ring plane, +Z at centre stone."""
import math
import sys
from pathlib import Path
import numpy as np

folder = Path(__file__).resolve().parent
root = (folder/'../../..').resolve()
sys.path.insert(0, str(root/'work/portrait-r3/libs'))
import manifold3d as mf
import trimesh as tm
M = mf.Manifold
pitch = 1.45
tilt = 41.0
width = 2.05
bottom = 1.44
distance_to_flat = 1.15

def vecmesh(s):
    data = s.to_mesh64()
    return tm.Trimesh(data.vert_properties[:,:3],data.tri_verts,process=False)

def manifold(mesh):
    return M(mf.Mesh64(np.asarray(mesh.vertices),np.asarray(mesh.faces,dtype=np.uint64)))

def casting_mesh(shape):
    from edge_finish import finish
    return finish(vecmesh(shape))

def blend(q):
    t=max(0,min(1,q))
    return t*t*(3-2*t)

def pocket(t):
    a=abs((t+180)%360-180)
    for c in [112,157]:
        d=abs(a-c)
        if d<18:return blend((18-d)/5)
    return 0.

def shank(r):
    rings=[]
    samples=480
    rfit = r/math.cos(math.pi/samples)
    for theta in np.arange(samples)*360/samples:
        a=math.radians(theta);at=abs((theta+180)%360-180)
        delta=math.radians(at-tilt)
        reach=math.atan(4.79/(r+distance_to_flat))
        factor=blend((reach+.105-abs(delta))/.105)
        outer=rfit+bottom
        if factor:
            outer+=( (r+distance_to_flat)/math.cos(delta)-outer)*factor
        p=pocket(theta)*.58
        w=width/2
        lip=.075-.048*factor
        section=[(outer-lip,-w),(outer,-w+lip),(outer,w-lip),(outer-lip,w),
                 (rfit+.075,w),(rfit,w-.075),(rfit,.27),
                 (rfit+p*.085,.254),(rfit+p*.90,.208),(rfit+p,.16),
                 (rfit+p,-.16),(rfit+p*.90,-.208),(rfit+p*.085,-.254),
                 (rfit,-.27),(rfit,-w+.075),(rfit+.075,-w)]
        rings.append([[rr*math.sin(a),y,rr*math.cos(a)] for rr,y in section])
    count=len(rings[0]);faces=[]
    for i in range(samples):
        for j in range(count):
            v0=i*count+j;v1=i*count+(j+1)%count
            v2=((i+1)%samples)*count+(j+1)%count;v3=((i+1)%samples)*count+j
            faces.extend([(v0,v1,v2),(v0,v2,v3)])
    m=tm.Trimesh(np.vstack(rings), faces, process=False)
    if m.volume<0:m.invert()
    return manifold(m)

def revolve(poly):
    return mf.CrossSection([poly]).revolve(144)

def gem(rings):
    vertices=[]
    for radius,z,n,offset in rings:
        for a in (np.arange(n)+offset)*2*np.pi/n:
            vertices.append([radius*math.cos(a),radius*math.sin(a),z])
    return M.hull_points(np.array(vertices))

def bead(radius,z0,z1,x,y):
    return M.cylinder(z1-z0,radius,radius,48).translate((x,y,z0))

def central(r):
    z0 = r+1.75
    stone=gem([(.024,0,8,0),(1.37,1.08,16,.5),(2.5,2.125,64,0),
               (2.5,2.195,64,0),(1.98,2.68,16,.5),(1.35,3.05,8,0)]).translate((0,0,z0))
    # The annulus follows the pavilion. End faces are square to the sloping
    # wall, so the lower rim does not feather out under the stone bearing.
    collar=revolve([(1.12,z0+.85),(1.71,z0+.205),(2.795,z0+1.215),
                    (2.205,z0+1.86)])
    arms=[]
    for a in np.deg2rad([45,135,225,315]):
        v=np.array([np.cos(a),np.sin(a)])
        levels=[(.77,r+1.10,.52),(1.25,r+1.74,.535),(2.17,r+2.71,.535),
                (2.93,z0+1.73,.505),(2.97,z0+2.12,.45),(2.97,z0+2.935,.45)]
        discs=[bead(d,h-.015,h+.015,*(v*s)) for s,h,d in levels]
        arms.extend(M.batch_hull(pair) for pair in zip(discs,discs[1:]))
    blank=M.batch_boolean([collar,*arms],mf.OpType.Add)
    v=vecmesh(stone).vertices
    sweep=M.hull_points(np.vstack([v,v+[0,0,5]]))
    return blank-sweep.translate((0,0,-.00002)),stone

def pave_stone():
    # The top diameter of the tapered window is 1.000 mm at local z=0.
    # Measured reference girdle sits above the deck. The annular bearing is
    # only contacted when the reference is pushed a further 0.020 mm down.
    return gem([(.010,-.416,8,0),(.412,-.055,16,.5),(.4998,0,48,0),(.625,.139,48,0),
                (.625,.175,48,0),(.467,.287,16,.5),(.33,.362,8,0)])

def tilted(shape,side,r):
    a=tilt*side
    n=np.array([math.sin(math.radians(a)),0.,math.cos(math.radians(a))])
    return shape.rotate((0,a,0)).translate(n*(r+distance_to_flat))

def french_notch(s,hand,flank):
    # The paired cuts splay at the flanks of each bearing, leaving metal
    # under the shared transverse grain. The cutter opens to the exterior;
    # its narrow back ends above the floor of the conical stone pocket.
    xyz=[]
    for side_y,centre,half,depth in [(1.22,.41,.265,-.53),(1.025,.45,.207,-.435),(.842,.522,.030,-.032)]:
        for dx,z in [(-half,.110),(half,.110),(.014,depth),(-.014,depth)]:
            xyz.append((s+hand*(centre+dx),flank*side_y,z))
    return M.hull_points(np.array(xyz))

def drill(s,r):
    inside=math.sqrt(r*r-s*s)-(r+distance_to_flat)
    radial=math.degrees(math.asin(s/r))
    nr=np.array([s/r,0,math.cos(math.radians(radial))])
    ring=np.array([s,0,inside])
    stem=M.cylinder(.94,.378,.378,96).rotate((0,radial,0)).translate(ring-.40*nr)
    hub=M.cylinder(.008,.378,.378,96).rotate((0,radial,0)).translate(ring+.52*nr)
    head=M.cylinder(.008,.488,.488,96).translate((s,0,-.155))
    cap=revolve([(0,-.16),(.488,-.16),(.5,0),(.5,.26),(0,.26)]).translate((s,0,0))
    return M.batch_boolean([stem,M.batch_hull([hub,head]),cap],mf.OpType.Add)

def series(size):
    r=size/2
    metal=shank(r)
    basket,stone=central(r)
    side_stone=pave_stone()
    metal=metal+basket
    stones={'Center':stone}
    additions=[];cutters=[]
    for side,label in [(-1,'L'),(1,'R')]:
        for i in range(6):
            s=side*(i-2.5)*pitch
            # Project the inner exit of each opening onto the fitted bore.
            # Inclined exits are elliptical in a section taken along the bore.
            # Circular exit square to the fitted finger bore. Each upper
            # mouth stays parallel to its six seat axes; connect both smooth
            # cylinders inside the metal clear of either visible opening.
            hole=drill(s,r)
            cutters.append(tilted(hole,side,r))
            for hand in (-1,1):
                for flank in (-1,1):
                    cutters.append(tilted(french_notch(s,hand,flank),side,r))
            st=tilted(side_stone.translate((s,0,0)),side,r)
            stones['Pave'+label+str(i+1).zfill(2)]=st
        for j in range(7):
            s=side*(j-3)*pitch
            for y in (-.525,.525):
                # Twin open shared grains; the ends are left straight for setting.
                foot=revolve([(0,-.10),(.304,-.10),(.304,.015),(.26,.155),
                              (.26,.505),(.252,.52),(0,.52)]).translate((s,y,0))
                additions.append(tilted(foot,side,r))
    metal=M.batch_boolean([metal,*additions],mf.OpType.Add)
    metal=M.batch_boolean([metal,*cutters],mf.OpType.Subtract).simplify(.00003)
    return metal,stones
