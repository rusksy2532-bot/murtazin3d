from model import *
from datetime import datetime
import json
import hashlib
sys.path.insert(0,str(root/'work/duet-casting-r3'))
from self_intersections import check_file

def now():return datetime.now().astimezone().isoformat(timespec='seconds')
def sample(mesh):return manifold(tm.load_mesh(mesh,process=True))
def vol(shape):return abs(shape.volume())
def pos(shape):return np.asarray(shape.bounding_box()[:3])
def emit(shape,name):
    path=folder/(name+'.stl')
    vecmesh(shape).export(path)
    mesh=tm.load_mesh(path,process=True)
    checked=manifold(mesh)
    assert checked.status()==mf.Error.NoError and mesh.is_volume,name
    return mesh,checked

def unit(a):return np.array([math.sin(math.radians(a)),0,math.cos(math.radians(a))])
def audit_file(size):
    start=now();r=size/2
    built,stones=series(size)
    name='Ring'+str(size)
    mesh,metal=emit(built,name)
    scene=tm.Scene()
    scene_mesh=mesh.copy()
    scene_mesh.visual=tm.visual.TextureVisuals(material=tm.visual.material.PBRMaterial(name='Warm gold Au 585',baseColorFactor=[237,191,117,255],metallicFactor=1.,roughnessFactor=.18))
    def put(m,name):
        m.apply_transform(tm.transformations.rotation_matrix(math.radians(-90),[1,0,0]))
        m.apply_scale(.001)
        scene.add_geometry(m,node_name=name,geom_name=name)
    put(scene_mesh,'Metal')
    stones_out={};stone_checks=[]
    for label,base in stones.items():
        fn=label.replace('PaveL','Pave'+str(size)+'-L').replace('PaveR','Pave'+str(size)+'-R') if label!='Center' else 'Center'+str(size)
        m,obj=emit(base,fn)
        forward=unit(0 if label=='Center' else tilt*(-1 if label[4]=='L' else 1))
        rise=5.0 if label=='Center' else 2.5
        sweep=M.hull_points(np.vstack([m.vertices,m.vertices+forward*rise]))
        test={'id':label,'filename':fn+'.stl','axis':forward.tolist(),'sweepMm':rise,
              'sweptOverlapMm3':vol(metal^sweep),'seatedOverlapMm3':vol(metal^obj),
              'overtravel0020Mm3':vol(metal^obj.translate(-.020*forward)),
              'axialHeightMm':float(np.ptp(m.vertices@forward))}
        stones_out[label]=obj;stone_checks.append(test)
        m.visual=tm.visual.TextureVisuals(material=tm.visual.material.PBRMaterial(name='Diamond',baseColorFactor=[232,242,251,255],metallicFactor=0,roughnessFactor=.045))
        put(m,label)
    scene.export(folder/(name+'.glb'))
    _,edges=np.unique(mesh.edges_sorted,axis=0,return_counts=True)
    q={'started':start,'size':size,'density585gCm3':13.15,'volumeMm3':mesh.volume,'mass585g':mesh.volume*.01315,
       'faces':len(mesh.faces),'shells':len(metal.decompose()),'openEdges':int(sum(edges==1)),
       'nonManifoldEdges':int(sum(edges>2)),'selfIntersections':check_file(folder/(name+'.stl'))['intersectingPairs'],
       'sha256':hashlib.sha256((folder/(name+'.stl')).read_bytes()).hexdigest(),'stones':stone_checks}
    def hits(a,b):
        return np.array([h.position for h in metal.ray_cast(a,b)])
    def length_hits(a,b):
        h=hits(a,b)
        return np.linalg.norm(h[1]-h[0]) if len(h)==2 else None
    def levels(x,y,side):
        n=unit(tilt*side);t=np.array([n[2],0,-n[0]])
        return n*(r+distance_to_flat)+t*x+np.array([0,y,0]),n,t
    sections=[]
    for side in (-1,1):
        for i in range(6):
            s=side*(i-2.5)*pitch;c,n,t=levels(s,0,side)
            bore=math.sqrt(r*r-s*s)-(r+distance_to_flat)
            row={'side':side,'index':i+1,'girdleMm':(c+n*.157).tolist()}
            for z,k in [(-.0002,'upper'),(bore+.04,'exit')]:
                axis=c+n*z
                ray=hits(axis,axis+np.array([0,2.,0]))
                row[k+'RadiusMm']=float(ray[0,1]) if len(ray) else None
                row[k+'SideWallMm']=float(ray[1,1]-ray[0,1]) if len(ray)>1 else None
            if i<5:
                ray=hits(c-n*.0002,c+side*t*pitch-n*.0002)
                row['upperBridgeMm']=float(np.linalg.norm(ray[1]-ray[0])) if len(ray)==2 else None
                other=stones_out['Pave'+('L' if side<0 else 'R')+str(i+2).zfill(2)]
                this=stones_out['Pave'+('L' if side<0 else 'R')+str(i+1).zfill(2)]
                row['adjacentStoneGapMm']=this.min_gap(other,1)
                # Find the two facing exit boundaries in their symmetry plane on the actual fitted bore.
                marks=[]
                for xsgn,sc in [(side,s),(-side,s+side*pitch)]:
                    low,high=0.,.65
                    for _ in range(24):
                        dx=(low+high)/2;x=sc+xsgn*dx
                        loc=c+(x-s)*t
                        inside_z=math.sqrt(r*r-x*x)-(r+distance_to_flat)
                        h=hits(loc+n*(inside_z-.09),loc+n*(inside_z+.02))
                        if len(h):high=dx
                        else:low=dx
                    x=sc+xsgn*(low+high)/2
                    marks.append(c+(x-s)*t+n*(math.sqrt(r*r-x*x)-(r+distance_to_flat)))
                row['exitBridgeMm']=float(np.linalg.norm(marks[0]-marks[1]))
            sections.append(row)
    q['shoulderSections']=sections
    q['centreFit']=dict(zGirdleTop=r+1.75+2.195,zTip=r+1.75+2.95,
                        finishedGirdleDiameterMm=5.,referenceHeightMm=3.05)
    ring_hits=hits([0,-.8,0],[0,-.8,-20])
    q['bottomThicknessMm']=float(np.linalg.norm(ring_hits[1]-ring_hits[0]))
    q['bottomWidthMm']=float(length_hits(np.array([0,-3,-r-.9]),np.array([0,3,-r-.9])))
    floors=[]; sides=[]; bores=[]
    for a in [101,111,121,147,157,167,193,203,213,239,249,259]:
        n=unit(a)
        h=hits(n*(r-.1),n*(r+2.))
        floors.append(float(np.linalg.norm(h[1]-h[0])))
        h=hits(n*(r+.24)-[0,1.4,0],n*(r+.24)+[0,1.4,0])
        sides.extend([float(h[1,1]-h[0,1]),float(h[3,1]-h[2,1])])
        h=hits(n*(r-.1)+[0,.8,0],n*(r+2)+[0,.8,0])
        bores.append(2*np.linalg.norm(h[0,[0,2]]))
    q['relief']={'floorsMm':floors,'sideWallsMm':sides,'boreCheckMm':bores}
    q['finished']=now()
    (folder/(name+'-qa.json')).write_text(json.dumps(q,indent=2),'utf8')
    print(name,round(q['mass585g'],4),'overlap',max(x['sweptOverlapMm3'] for x in stone_checks),
          'contact',min(x['overtravel0020Mm3'] for x in stone_checks),
          'bridge',sections[0]['upperBridgeMm'],'exit',sections[0]['exitBridgeMm'],
          'gaps',sections[0]['adjacentStoneGapMm'],'topology',q['selfIntersections'],flush=True)
if __name__=='__main__':
    for size in map(int,sys.argv[1:] or (17,16,18)):audit_file(size)
