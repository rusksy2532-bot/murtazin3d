"""Duet workshop master. All constructive dimensions in mm, Y up, +Z joint opening.

Portable rebuild: python blank.py --source catalog-duet.glb --out Duet-Casting-R3
"""
from pathlib import Path
import argparse, json, sys
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',type=Path)
parser.add_argument('--out',type=Path)
args=parser.parse_args()
here=Path(__file__).resolve().parent
import numpy as np
from scipy.spatial import ConvexHull
import trimesh as tm
import manifold3d as mf
import networkx as nx

out=args.out or here/'Duet-Casting-R3'
(out/'stones').mkdir(exist_ok=True, parents=True)
source=args.source or here/'catalog-duet.glb'
sc=tm.load_scene(source,process=False)
M=mf.Manifold
def union(shapes):
    return M.batch_boolean(shapes,mf.OpType.Add)
def mesh(s):
    a=s.to_mesh64()
    return tm.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=False)
def solid(m):
    s=M(mf.Mesh64(np.array(m.vertices,dtype='float64'),np.array(m.faces,dtype='uint64')))
    assert s.status()==mf.Error.NoError
    return s
def cleanup(m):
    m.merge_vertices(merge_tex=True,merge_norm=True,digits_vertex=6)
    m.update_faces(m.nondegenerate_faces(height=1e-8))
    m.remove_unreferenced_vertices()
def cap_tube(part):
    edges,n=np.unique(part.edges_sorted,axis=0,return_counts=True)
    edges=edges[n==1]
    if len(edges):
        f=part.faces.tolist()
        verts=part.vertices.tolist()
        for loop in nx.cycle_basis(nx.from_edgelist(edges.tolist())):
            k=len(verts)
            verts.append(part.vertices[loop].mean(axis=0))
            f.extend([j,loop[(i+1)%len(loop)],k] for i,j in enumerate(loop))
        part=tm.Trimesh(verts,f,process=False)
    part.fix_normals()
    return solid(part)
def strengthen_brace(part, factor):
    # Scale the actual cross-section about its center at every station.
    edges,n=np.unique(part.edges_sorted,axis=0,return_counts=True)
    ends=list(nx.connected_components(nx.from_edgelist(edges[n==1].tolist())))
    assert len(ends)==2
    rings=nx.multi_source_dijkstra_path_length(nx.from_edgelist(edges.tolist()),ends[0],weight=None)
    vertices=part.vertices.copy()
    for level in set(rings.values()):
        ids=[k for k,i in rings.items() if i==level]
        assert len(ids)==len(ends[0])
        center=vertices[ids].mean(axis=0)
        vertices[ids]=center+(vertices[ids]-center)*factor
    part.vertices=vertices
    return part
def tube(a,b,r):
    return solid(tm.creation.cylinder(radius=r,sections=40,segment=[a,b]))
def ring(contour,scale,z0,z1,w):
    path=mf.CrossSection([contour*scale])
    return (path.offset(w)-path.offset(-w)).extrude(z1-z0).translate((0,0,z0))
def sphere(p,r):
    return M.sphere(r,24).translate(p)
def pull(mesh_raw,t):
    m=mesh_raw.copy()
    m.apply_transform(t)
    cleanup(m)
    return m
def round_brilliant():
    # The full-size girdle has 64 segments; main pavilion and table have eightfold symmetry.
    tiers=[]
    for rad,z,n,phase in [(.007,-.421,8,0),(.30,-.192,16,.5),(.5,-.012,64,0),
                           (.5,.012,64,0),(.416,.090,16,.5),(.285,.166,8,0)]:
        a=2*np.pi*(np.arange(n)+phase)/n
        tiers.append(np.column_stack([rad*np.cos(a),rad*np.sin(a),np.full(n,z)]))
    return mesh(M.hull_points(np.vstack(tiers)))
blank={'White':[], 'Champagne':[]}
gem_shapes={}
stone_tools=[]
meta=[]
for n in sc.graph.nodes_geometry:
    t,key=sc.graph[n]
    t=t.copy()
    t[:3,:]*=1000
    raw=sc.geometry[key]
    m=pull(raw,t)
    if n in ['Белое золото','Шампанское золото']:
        which='White' if n=='Белое золото' else 'Champagne'
        parts=m.split(only_watertight=False,repair=False)
        if which=='Champagne':
            # Lift the crossover axially away from the neighboring white crown.
            # The shaped transition fades before either shoulder joint.
            for k in (0,13):
                v=parts[k].vertices.copy()
                weight=np.exp(-((v[:,0]+1.85)/2.85)**4)*np.clip((v[:,1]-6)/3,0,1)
                v[:,2]+=1.08*weight
                parts[k].vertices=v
        else:
            # Broaden the white shoulder across the finger to root the new grains fully.
            v=parts[0].vertices.copy()
            a=np.arctan2(v[:,1],v[:,0]); si=np.sin(a); co=np.cos(a)
            f=np.clip((si+.16)/1.16,0,1); crest=f*f*(3-2*f)
            center=crest*(-2.32+.95*co)
            widen=.53*np.exp(-((np.rad2deg(a)-140.)/28.)**8)
            v[:,2]+=widen*(v[:,2]-center)
            parts[0].vertices=v
            # Bend the left gallery brace toward the open space between ribbons
            # so the setter can reach all four standing grains of the first two melee.
            v=parts[13].vertices.copy()
            u=np.clip((v[:,1]-6.95)/1.0,0,1)
            w=np.clip((10.03-v[:,1])/.92,0,1)
            v[:,2]+=.78*(u*u*(3.-2.*u))*(w*w*(3.-2.*w))
            parts[13].vertices=v
        blank[which].append(cap_tube(parts[0]))
        blank[which].extend(cap_tube(strengthen_brace(parts[k],1.38)) for k in (13,14))
        continue
    if n.startswith('R&R'):
        continue
    m.fix_normals()
    is_round=n.startswith('Круглый')
    if is_round:
        index=int(n.split()[-1])
        if index>5:
            continue
        id=f'Pave{index:02d}'
        label=f'Паве {index:02d}'
        # Keep the melee on the original white ribbon but extend the run slightly.
        # Graduated pitch leaves material and tool access between opposite pairs of grains.
        angles=[119.,129.65,140.30,150.95,161.60]
        a=np.deg2rad(angles[index-1])
        x,y=np.cos(a),np.sin(a)
        f=np.clip((y+.16)/1.16,0,1)
        crest=f*f*(3.-2.*f)
        radius=9.18+crest*(.38+.60*x)+.66-.04*crest
        t[:3,:3]=np.array([[y,-x,0],[0,0,-1],[x,y,0]]).T
        t[:3,3]=[x*radius,y*radius,crest*(-2.32+.95*x)]
        raw=round_brilliant()
        m=pull(raw,t)
        m.fix_normals()
    else:
        id='PearTeal' if 'Индиголит' in n else 'PearWhite'
        label='Индиголит' if id=='PearTeal' else 'Бесцветная груша'
    which='Champagne' if id=='PearTeal' else 'White'
    gem_shapes[id]=solid(m)
    direction=t[:3,2]/np.linalg.norm(t[:3,2])
    local=np.asarray(raw.vertices)
    contour=local[ConvexHull(local[:,:2]).vertices,:2]
    width,length=np.ptp(contour,axis=0)
    # Projected silhouette excludes crown/pavilion; the extrusion is the approach clearance.
    section=mf.CrossSection([contour])
    travel=3 if is_round else 6
    clearance=.045 if is_round else .065
    upper=section.offset(clearance).extrude(travel+2).translate((0,0,-.015 if is_round else -.055))
    cutter=M.hull_points(np.vstack([local,local+[0,0,travel]]))+upper
    # Access beneath the culet. The remaining shoulder of pavilion supports the stone.
    fraction=.53 if is_round else .74
    throat=mf.CrossSection([contour*fraction])
    if is_round:
        pilot=throat.extrude(9).translate((0,0,-8))
    else:
        # Only the crown of the open basket needs the full light opening.
        # A smaller diverging bore at long range leaves solid shank stock.
        small=mf.CrossSection([contour*.45])
        deep=small.extrude(6.04).translate((0,0,-8))
        wide=throat.extrude(2.48).translate((0,0,-1.48))
        transition=M.batch_hull([small.extrude(.01).translate((0,0,-2.00)),
                                 throat.extrude(.01).translate((0,0,-1.48))])
        pilot=deep+transition+wide
        # Relieve the underside of the bearing: vertical inner wall below
        # the final upper pavilion makes the loading land a shoulder, instead
        # of leaving an acute ledge where the lower face meets the pavilion.
        undercut=(cutter+pilot).slice(-.105).extrude(.54).translate((0,0,-.644))
        if which=='White':
            # Extend the actual inner shoulder to the lower gallery through a
            # rounded load-bearing web. Retain the bearing surface in this sector.
            landmark=(np.linalg.inv(t)@np.array([-3.155,10.73,.622,1.]))[:2]
            web=M.cylinder(1.08,.62,.62,72).translate((*landmark,-1.48))
            blank[which].append(web.transform(t[:3]))
            # Continue the backed bearing all the way outward to the main
            # gallery. A circular cut-off alone would leave two separate
            # material intervals on some lines normal to the pavilion.
            toward_outside=t[:3,:2].T@np.array([-.30,0,.954])
            stop=M.batch_hull([M.cylinder(1.6,r,r,72).translate((*(landmark+toward_outside*d),-1.48))
                               for r,d in ((.62,0),(1.32,.85))])
            undercut=undercut-stop
        else:
            landmark=(np.linalg.inv(t)@np.array([-.22,10.65,1.88,1.]))[:2]
            web=M.cylinder(1.02,.62,.62,72).translate((*landmark,-1.43))
            blank[which].append(web.transform(t[:3]))
        pilot=pilot+undercut
    stone_tools.append((cutter+pilot).transform(t[:3]))
    tip_points=[]
    if is_round:
        # Four standing grains flank the stone; space them along the Z sides
        # of the row where neighbouring melee cannot block the setter.
        r=width/2
        for sx in (-1,1):
            for sy in (-1,1):
                radial=np.array([sx*.55,sy*.835]);radial/=np.linalg.norm(radial)
                center=(r+.295)*radial
                top=np.r_[center,.412]
                bottom=np.r_[center,-.82]
                neck=np.r_[center,-.12]
                root_pad=M.cylinder(.70,.33,.27,48).translate(bottom)
                dome=M.sphere(1,40).scale([.27,.27,.15]).translate(top)
                grain=root_pad+tube(neck,top,.27)+dome
                blank[which].append(grain.transform(t[:3]))
                tip_points.append((t[:3,:3]@(top+[0,0,.15])+t[:3,3]).tolist())
    else:
        # Each gallery follows the complete actual cutter, including the open culet hole.
        # Both the axial stock and the planar radius are explicit rather than left
        # to the residual sliver of a round wire after cutting.
        opening=cutter+pilot
        for low,high in [(-1.48,-.85),(-.63,.015)]:
            inner=opening.slice(high+.002)
            outer=inner.offset(.555 if which=='White' else .550,circular_segments=90)
            if high>0:
                # Two opposing flats clear the two crowns while leaving at least
                # 0.51 mm outside the stone tooling around the whole perimeter.
                n=np.array([.762,0,.648]);n/=np.linalg.norm(n)
                threshold=.390
                if which=='White':
                    n,threshold=-n,-.257
                n2=(n@t[:3,:2]); n2/=np.linalg.norm(n2)
                tangent=np.array([-n2[1],n2[0]])
                base_point=n2*(threshold-n@t[:3,3])
                boundary=mf.CrossSection.hull_points([base_point+n2*d+tangent*u
                                                      for d in (0,30) for u in (-30,30)])
                outer=(outer^boundary)+inner.offset(.510,circular_segments=90)
            collar=outer.extrude(high-low).translate((0,0,low))
            blank[which].append(collar.transform(t[:3]))
        stations=[0,3,6,10,12 if which=='Champagne' else 13]
        assert len(contour)==16 and len(set(k%len(contour) for k in stations))==5
        for k in stations:
            # Geometric stations, measured from the pointed end.
            start=np.argmax(contour[:,0])
            j=(start+k)%len(contour)
            p=contour[j]
            tangent=contour[(j+1)%len(contour)]-contour[(j-1)%len(contour)]
            normal=np.array([tangent[1],-tangent[0]])
            normal/=np.linalg.norm(normal)
            r=.36 if k==0 else .325
            lower=np.r_[p*.77,-1.12]
            upper_xy=p+normal*(r+.052)
            shoulder=np.r_[upper_xy,-.29]
            top=np.r_[upper_xy,.047+.78-r]
            claw=tube(lower,shoulder,r)+sphere(shoulder,r)+tube(shoulder,top,r)+sphere(top,r)
            claw=claw.transform(t[:3])
            blank[which].append(claw)
            tip_points.append((t[:3,:3]@(top+[0,0,r])+t[:3,3]).tolist())
    meta.append(dict(id=id,label=label,centerMm=t[:3,3].tolist(),direction=direction.tolist(),strokeMm=travel,
                     sizeMm=np.ptp(local,axis=0).round(4).tolist(),alloy=which,prongs=4 if is_round else 5,
                     upperGirdleOffsetMm=.012 if is_round else .047,
                     prongCentersMm=tip_points,radialEntryClearanceMm=clearance))

def block(bot,top):
    lo,hi=np.array(bot),np.array(top)
    return M.cube(hi-lo).translate(lo)
white,warm=[union(blank[c]) for c in ('White','Champagne')]
# Relieve only the inset shoulders; keep a full-width lower shank under the finger.
zbase=.32
seatbox=block([-13,-2,zbase],[13,5,8])
white=white-seatbox
warm=warm-block([-13,-7,-8],[13,5,zbase])
# Replace the partial intersection of the tapered ribbon with complete flat tongues.
# The new y=-0.58 end faces have a real end thickness instead of a feather edge.
warm=warm-block([-13,-7,-8],[13,1.35,8])
pins=[]
for x in [-9.46,9.46]:
    y=1.05
    axis=np.array([x,y])
    outline=mf.CrossSection.square((.88,1.57),center=True).offset(.15,circular_segments=48)
    toe=outline.extrude(.56).translate((np.sign(x)*9.34,.355,zbase))
    warm=warm+toe
    cap=M.cylinder(1.54,1.02,1.02,80)+M.cylinder(.12,1.02,.90,80).translate((0,0,1.54))
    cap=cap.translate((*axis,zbase))
    # Extend the lap up the ribbon at each shoulder, giving an accessibly sized weld land.
    wing=tube([x,y,.78],[x*.958,2.55,.77],.45)
    warm=warm+cap+wing
    white=white+M.cylinder(.55,1.02,1.02,80).translate((*axis,zbase-.55))
    peg=M.cylinder(.662,.35,.35,64).translate((*axis,zbase-.002))
    lead=M.cylinder(.100,.35,.27,64).translate((*axis,zbase+.660))
    white=white+peg+lead
    def slot(profile):
        if x<0:
            return M.batch_hull([profile.translate((-.07,0,0)),profile.translate((.07,0,0))])
        return profile
    bore=(slot(M.cylinder(.890,.41,.41,64))+slot(M.cylinder(.09,.485,.41,64))).translate((*axis,zbase-.010))
    warm=warm-bore
    pins.append(dict(centerMm=[x,y,zbase],pinDiameterMm=.70,holeDiameterMm=.82,projectionMm=.760,
                     socketDepthMm=.880,padDiameterMm=2.04,socketWidthMm=.82,
                     socketLengthMm=.96 if x<0 else .82,capHeightMm=1.66,
                     socketType='oblong' if x<0 else 'round'))

tools=union(stone_tools)
bore=M.cylinder(14,8.5003/np.cos(np.pi/360),circular_segments=360).translate((0,0,-7))
white=(white.simplify(.0003)-tools-bore).simplify(.000008)
warm=(warm.simplify(.0003)-tools-bore).simplify(.000008)
for name,s in [('White',white),('Champagne',warm)]:
    print(name,[(round(k.volume(),5),k.bounding_box()) for k in s.decompose()],flush=True)
print('join offset overlap samples',[(d,round((white^warm.translate((0,0,d))).volume(),6)) for d in (0,.05,.2,.5,1,2,4,6,8)],flush=True)
gltf=tm.Scene()
def export_body(name,s,path,material):
    m=mesh(s)
    m.export(path)
    m=tm.load_mesh(path,process=False)
    cleanup(m)
    m.export(path)
    print('export',name,len(m.faces),len(m.split(only_watertight=False)),m.is_volume,flush=True)
    m.apply_scale(.001)
    m.visual=tm.visual.TextureVisuals(material=material)
    gltf.add_geometry(m,node_name=name,geom_name=name)
def mat(name,rgba,metal,rough):
    return tm.visual.material.PBRMaterial(name=name,baseColorFactor=rgba,metallicFactor=metal,roughnessFactor=rough)
export_body('White',white,out/'White.stl',mat('Белое золото',[228,227,224,255],1,.23))
export_body('Champagne',warm,out/'Champagne.stl',mat('Золото шампань',[226,191,135,255],1,.25))
for name,s in gem_shapes.items():
    rgba=[55,151,147,255] if name=='PearTeal' else [197,222,235,255]
    export_body(name,s,out/'stones'/f'{name}.stl',mat(name,rgba,.2,.09))
gltf.export(out/'Assembly.glb')
meta.sort(key=lambda g:(g['id'].startswith('Pave'),g['id']=='PearTeal',g['id']))
record=dict(stones=meta,units='mm',joint=dict(moving='Champagne',direction=[0,0,1],strokeMm=8,pins=pins))
(out/'assembly.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
